package br.com.mercadinho.estoque_api.controller;

import br.com.mercadinho.estoque_api.dto.LoginRequest;
import br.com.mercadinho.estoque_api.dto.LoginResponse;
import br.com.mercadinho.estoque_api.service.AuthService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public LoginResponse login(@RequestBody LoginRequest request) {
        return authService.login(request);
    }
}