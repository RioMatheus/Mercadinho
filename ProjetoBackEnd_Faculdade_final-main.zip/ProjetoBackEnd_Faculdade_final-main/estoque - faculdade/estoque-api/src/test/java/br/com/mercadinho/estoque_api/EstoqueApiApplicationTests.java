package br.com.mercadinho.estoque_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstoqueApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
